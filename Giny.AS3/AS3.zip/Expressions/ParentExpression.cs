﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Giny.AS3.Expressions
{
    public abstract class ParentExpression : BaseExpression
    {
        public ParentExpression(string line) : base(line)
        {
        }
    }
}
